RegisterNetEvent('nom-notify:show')
AddEventHandler('nom-notify:show', function(message, type, duration)
    -- Function to replace color tags with HTML spans
    local function applyColorTags(text)
        if text == nil then
            print("[nom-notify] Error: message is nil!")
            return "" -- Return empty string if message is nil
        end

        -- Replace color tags with HTML
        text = text:gsub("~g~", "<span style='color:#388E3C;'>")
        text = text:gsub("~r~", "<span style='color:#D32F2F;'>")
        text = text:gsub("~b~", "<span style='color:#1976D2;'>")
        text = text:gsub("~o~", "<span style='color:#F57C00;'>")
        text = text:gsub("~s~", "</span>")  -- ~s~ closes the color span tag
        return text
    end

    -- Process the message to apply colors
    local coloredMessage = applyColorTags(message)

    -- Send the processed message to NUI for displaying
    SendNUIMessage({
        type = type,
        message = coloredMessage,
        duration = duration
    })
end)

-- Export function for other resources to use
exports('sendNotification', function(message, type, duration)
    TriggerEvent('nom-notify:show', message, type, duration)
end)


-- Command to test all notifications
RegisterCommand('testNotify', function()
    -- Test all four notification types
    TriggerEvent('nom-notify:show', "This is a ~bold~~g~success~s~~bold~ notification", "success", 5000) -- 5 seconds
    Citizen.Wait(100) -- Wait for 1 second before showing the next notification
    TriggerEvent('nom-notify:show', "This is an ~r~error~s~ notification", "error", 4000)-- 4 seconds
    Citizen.Wait(100) -- Wait for 1 second before showing the next notification
    TriggerEvent('nom-notify:show', "This is an ~b~info~s~ notification", "info", 3000)-- 3 seconds
    Citizen.Wait(100) -- Wait for 1 second before showing the next notification
    TriggerEvent('nom-notify:show', "This is a ~o~warning~s~ notification", "warning", 2000)-- 2 seconds
end, false)

-- [ Helpers ]

-- To make use of the word colors and syles, these are the available ones:

-- ~bold~ (to open the bold) This sentence is bold ~bold~ (to close the bold)
-- ~g~ (to open the green color) This sentence is green ~s~ (to close the color)
-- ~r~ (to open the red color) This sentence is red ~s~ (to close the color)
-- ~b~ (to open the blue color) This sentence is blue ~s~ (to close the color)
-- ~o~ (to open the orange color) This sentence is orange ~s~ (to close the color)

-- Client Sided export usage:

-- exports['nom-notify']:sendNotification("message", "type", duration) -- duration example: 5000

-- Server Sided Event usage:

-- TriggerClientEvent('nom-notify:show', playerId, "message", "type", duration) -- duration example: 5000