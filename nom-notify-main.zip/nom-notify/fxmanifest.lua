fx_version 'cerulean'
game 'gta5'

client_script 'client.lua'
server_script 'server.lua'

ui_page 'ui/index.html'  -- Specify the location of the HTML file for NUI

files {
    'ui/index.html',      -- HTML
    'ui/style.css',       -- CSS
    'ui/script.js'        -- JavaScript
}

exports {
    'sendNotification' -- Export for triggering notifications
}
