-- server.lua

RegisterServerEvent('nom-notify:trigger')
AddEventHandler('nom-notify:trigger', function(message, type)
    -- Trigger the notification on the client side for the sender
    TriggerClientEvent('nom-notify:show', source, message, type)
end)
