window.addEventListener('message', function (event) {
    const notificationContainer = document.getElementById('notification-container');
    const notificationMessage = event.data.message;
    const notificationType = event.data.type;
    const duration = event.data.duration || 3000; // Default to 3000ms if no duration is provided

    // Function to process the message and replace color and bold tags
    const applyColorAndBoldTags = (text) => {
        if (!text) return "";  // Ensure the message is not empty or undefined

        // Handle color tags
        text = text.replace(/~g~/g, '<span style="color:#388E3C;">');  // Green
        text = text.replace(/~r~/g, '<span style="color:#D32F2F;">');  // Red
        text = text.replace(/~b~/g, '<span style="color:#1976D2;">');  // Blue
        text = text.replace(/~o~/g, '<span style="color:#F57C00;">');  // Orange
        text = text.replace(/~s~/g, '</span>');  // Close the span tag
        
        // Handle bold tags (using ~bold~ instead of ~b~)
        text = text.replace(/~bold~(.*?)~bold~/g, '<strong>$1</strong>');  // Bold tag for text
        
        return text;
    };

    // Only process the message if it is valid
    const formattedMessage = notificationMessage ? applyColorAndBoldTags(notificationMessage) : '';

    // If the message is empty or invalid, do not create the notification
    if (!formattedMessage) return;

    // Create notification element
    const notificationElement = document.createElement('div');
    notificationElement.classList.add('notification', notificationType);

    // Dynamically set the animation duration for the bottom line
    notificationElement.style.setProperty('--animation-duration', `${duration}ms`);

    // Create the icon container
    const iconContainer = document.createElement('div');
    iconContainer.classList.add('icon-container');

    // Create the icon element
    const iconElement = document.createElement('i');
    iconElement.classList.add('notification-icon');

    // Assign an icon based on the notification type
    switch (notificationType) {
        case 'success':
            iconElement.classList.add('fas', 'fa-check-circle');
            break;
        case 'error':
            iconElement.classList.add('fas', 'fa-times-circle');
            break;
        case 'info':
            iconElement.classList.add('fas', 'fa-info-circle');
            break;
        case 'warning':
            iconElement.classList.add('fas', 'fa-exclamation-triangle');
            break;
        default:
            iconElement.classList.add('fas', 'fa-bell'); // Default icon
            break;
    }

    // Append the icon to the icon container
    iconContainer.appendChild(iconElement);

    // Create message container and append the processed message
    const messageContainer = document.createElement('div');
    messageContainer.classList.add('message-container');
    messageContainer.innerHTML = formattedMessage;  // Use innerHTML to render the HTML

    // Append the icon container and message container to the notification
    notificationElement.appendChild(iconContainer);
    notificationElement.appendChild(messageContainer);

    // Append the new notification to the container
    notificationContainer.appendChild(notificationElement);

    // Fade in the notification
    setTimeout(() => {
        notificationElement.style.opacity = 1;
    }, 50);

    // After the specified duration, fade out and remove the notification after the line animation
    setTimeout(() => {
        notificationElement.style.opacity = 0;
        setTimeout(() => {
            notificationContainer.removeChild(notificationElement);
        }, 500); // Wait for fade-out to finish
    }, duration); // Wait for both the duration and fade-out time
});
